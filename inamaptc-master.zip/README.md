# inamaptc
visor terrenos cinegéticos para movilidad del Instituto Aragonés de Gestión ambiental
usa leaflet y jquery jquery mobile
usa argis plugin para leaflet
capas de inaga contenidas en argis server coprporativo.
features:
  Localizar 1 coto  en el mapa
  Localizar cotos alrededor de mi posición
  Localizar cotos alrededor de las coordenadas doble-tap en el mapa, datos orto y ocaso y municipios afectados.
  Buscar localidades y obtener cotos colindates en el mapa.
  Obtener información del coto en el mapa. Tap
  Localizar un coto por coordenadas UTM ETR89 30N O GEOGRÁFICAS WS84
  Cambiar las capas bases de referencia.
  
